class Property < ActiveRecord::Base
end
