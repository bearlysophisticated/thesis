class AccommodationServiice < ActiveRecord::Base
	belongs_to :accommodation
	belongs_to :serviice
end
