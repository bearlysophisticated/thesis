require 'test_helper'

class ServiiceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
