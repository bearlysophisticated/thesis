require 'test_helper'

class RoomEquipmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
