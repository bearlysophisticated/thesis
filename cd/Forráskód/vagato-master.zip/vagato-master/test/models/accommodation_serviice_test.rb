require 'test_helper'

class AccommodationServiiceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
