require 'test_helper'

class BookingsGuestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
