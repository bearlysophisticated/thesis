require 'test_helper'

class EquipmentRoomTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
