require 'test_helper'

class RoomsHelperTest < ActionView::TestCase
end
