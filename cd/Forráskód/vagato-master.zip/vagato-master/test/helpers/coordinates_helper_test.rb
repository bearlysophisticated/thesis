require 'test_helper'

class CoordinatesHelperTest < ActionView::TestCase
end
