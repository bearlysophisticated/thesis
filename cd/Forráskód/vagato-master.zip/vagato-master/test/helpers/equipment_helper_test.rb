require 'test_helper'

class EquipmentHelperTest < ActionView::TestCase
end
