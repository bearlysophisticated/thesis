require 'test_helper'

class AddressesHelperTest < ActionView::TestCase
end
