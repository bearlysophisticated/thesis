require 'test_helper'

class AccommodationsHelperTest < ActionView::TestCase
end
