require 'test_helper'

class AccommodationEquipmentsHelperTest < ActionView::TestCase
end
