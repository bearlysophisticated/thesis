require 'test_helper'

class CategriesHelperTest < ActionView::TestCase
end
