require 'test_helper'

class PagesHelperTest < ActionView::TestCase
end
