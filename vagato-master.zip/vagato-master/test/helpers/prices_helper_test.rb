require 'test_helper'

class PricesHelperTest < ActionView::TestCase
end
