require 'test_helper'

class BookingsRoomTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
