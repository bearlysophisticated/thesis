require 'test_helper'

class AccommodationEquipmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
