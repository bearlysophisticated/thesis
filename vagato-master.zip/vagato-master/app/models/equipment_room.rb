class EquipmentRoom < ActiveRecord::Base
end
