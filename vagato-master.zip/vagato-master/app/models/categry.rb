class Categry < ActiveRecord::Base
	has_many :accommodations
end
