class Serviice < ActiveRecord::Base
end
